import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path
import warnings

# Suppress font warnings
warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib')

# Configuration
SCRIPT_DIR = Path(__file__).parent
GEOJSON_PATH = SCRIPT_DIR / "england_complete_road_network.geojson"
DEPOT_CSV_PATH = SCRIPT_DIR / "depot_details.csv"

def load_depot_data():
    """Load depot data from CSV file"""
    try:
        df = pd.read_csv(DEPOT_CSV_PATH)
        print(f"Successfully loaded {len(df)} depot records")
        
        # Filter out depots with invalid coordinates (0,0)
        valid_depots = df[(df['Latitude'] != 0) & (df['Longitude'] != 0)]
        print(f"Found {len(valid_depots)} depots with valid coordinates")
        
        return valid_depots
    except Exception as e:
        print(f"Error loading depot data: {e}")
        return None

def plot_england_network_with_depots():
    """Plot complete England road network map with depot locations"""
    print("Loading complete England road network...")
    
    try:
        # Load GeoJSON file
        gdf = gpd.read_file(GEOJSON_PATH)
        print(f"Successfully loaded {len(gdf):,} road features")
        
        # Load depot data
        depot_df = load_depot_data()
        if depot_df is None:
            print("Failed to load depot data, plotting network only")
            depot_df = pd.DataFrame()
        
        # Set font to avoid Chinese character issues
        plt.rcParams['font.family'] = 'DejaVu Sans'
        
        # Create the plot
        fig, ax = plt.subplots(figsize=(18, 14))
        
        # Get unique areas and assign colors
        unique_areas = gdf['area_name'].unique()
        colors = plt.cm.tab20(np.linspace(0, 1, len(unique_areas)))
        
        # Plot all road areas
        for i, area in enumerate(unique_areas):
            area_data = gdf[gdf['area_name'] == area]
            area_data.plot(ax=ax, color=colors[i], linewidth=0.8, alpha=0.7, label=f'Area {area}')
        
        # Plot depot locations if available
        if not depot_df.empty:
            # Convert depot coordinates to GeoDataFrame
            depot_gdf = gpd.GeoDataFrame(
                depot_df, 
                geometry=gpd.points_from_xy(depot_df['Longitude'], depot_df['Latitude']),
                crs='EPSG:4326'
            )
            
            # Transform to same CRS as road network
            depot_gdf = depot_gdf.to_crs(gdf.crs)
            
            # Plot operational and non-operational depots with different colors
            operational_depots = depot_gdf[depot_gdf['Operational?'] == 'Y']
            non_operational_depots = depot_gdf[depot_gdf['Operational?'] == 'N']
            
            if not operational_depots.empty:
                operational_depots.plot(ax=ax, color='green', markersize=10, alpha=0.9, 
                                      marker='o', label='Operational Depots')
            
            if not non_operational_depots.empty:
                non_operational_depots.plot(ax=ax, color='red', markersize=10, alpha=0.9, 
                                          marker='s', label='Non-Operational Depots')
            
            # Add depot labels for high-capacity depots
            high_capacity = depot_gdf[depot_gdf['Brown Salt Capacity'] > 5000]
            for idx, depot in high_capacity.iterrows():
                ax.annotate(f"{depot['Depot Names']}\n({depot['Brown Salt Capacity']:,}t)", 
                           xy=(depot.geometry.x, depot.geometry.y), 
                           xytext=(5, 5), textcoords='offset points',
                           fontsize=8, alpha=0.8,
                           bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))
        
        # Set plot properties
        ax.set_title("Complete England Road Network with Depot Locations", fontsize=16, fontweight='bold')
        ax.set_xlabel("Easting (m)")
        ax.set_ylabel("Northing (m)")
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal')
        
        # Add legend
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)
        
        # Add network info
        info_text = f"Total Areas: {len(unique_areas)}\nTotal Features: {len(gdf):,}"
        if not depot_df.empty:
            info_text += f"\nTotal Depots: {len(depot_df)}\nOperational: {len(depot_df[depot_df['Operational?'] == 'Y'])}"
        
        ax.text(0.02, 0.98, info_text, 
                transform=ax.transAxes, fontsize=10, 
                bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8),
                verticalalignment='top')
        
        # Adjust layout and show
        plt.tight_layout()
        plt.show()
        
        print(f"Map plotting completed. Total areas: {len(unique_areas)}")
        if not depot_df.empty:
            print(f"Depots plotted: {len(depot_df)} (Operational: {len(depot_df[depot_df['Operational?'] == 'Y'])}, Non-operational: {len(depot_df[depot_df['Operational?'] == 'N'])})")
        
    except FileNotFoundError as e:
        print(f"Error: File not found - {e}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    plot_england_network_with_depots()
