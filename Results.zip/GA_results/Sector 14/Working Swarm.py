
    
    
import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import networkx as nx
from shapely.geometry import Point, LineString
from pathlib import Path
import random
import warnings
from collections import defaultdict
import pickle
from datetime import datetime
import pyproj
import string

warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")

# =====================
# CONFIGURATION
# =====================
SCRIPT_DIR = Path(__file__).parent
GEOJSON_PATH = SCRIPT_DIR / "area14_section_from_full.geojson"
DEPOT_TXT_PATH = SCRIPT_DIR / "best_solution_4_depots.txt"

# Performance & behaviour
AVERAGE_SPEED_KMH = 80
BUFFER_METERS = 1000

# ACO parameters
ACO_ENABLED = True
N_ANTS = 12
N_ITERATIONS = 100
ALPHA = 0.3
BETA = 6.0
RHO = 0.1
STEPS = 8000

# Multi-vehicle
VEHICLES_PER_DEPOT = 6

# Simplification tolerance (meters in projected CRS)
SIMPLIFY_TOLERANCE = 200

# Max iterations for connecting subnetworks
MAX_CONNECT_ITER = 130000

# Cache files
GRAPH_CACHE_PATH = SCRIPT_DIR / "connected_network_full.pkl"
SAVE_CONNECTED_GEOJSON = SCRIPT_DIR / "connected_bridges_full.geojson"
FINAL_GRAPH_CACHE_PATH = SCRIPT_DIR / "final_graph_after_aco.pkl"

# Subnetwork rebuild control
FORCE_RECONNECT_SUBNETWORKS = False

# =====================
# HELPERS
# =====================
def travel_time_hours(distance_m):
    return distance_m / 1000.0 / AVERAGE_SPEED_KMH

def euclid(a, b):
    return np.hypot(a[0] - b[0], a[1] - b[1])

# =====================
# LOAD DATA
# =====================
def load_routes_and_depots(geojson_path, depot_csv):
    print(f"Loading routes from: {geojson_path.name}")
    routes_gdf = gpd.read_file(geojson_path).to_crs(epsg=3857)

    if len(routes_gdf) > 1000:
        print(f"Simplifying geometries (tolerance={SIMPLIFY_TOLERANCE}m)...")
        routes_gdf["geometry"] = routes_gdf["geometry"].simplify(SIMPLIFY_TOLERANCE, preserve_topology=True)
        routes_gdf = routes_gdf[~routes_gdf["geometry"].is_empty].copy()

        fig, ax = plt.subplots(figsize=(10, 8))
        routes_gdf.plot(ax=ax, color="steelblue", linewidth=0.8, alpha=0.8)
        ax.set_title(f"Preview: Simplified Route Geometry ({SIMPLIFY_TOLERANCE} m tolerance)")
        ax.set_aspect("equal")
        plt.tight_layout()
        plt.show()

    coords = []
    if str(depot_csv).lower().endswith(".txt"):
        with open(depot_csv, "r") as f:
            lines = f.readlines()
        for line in lines:
            line = line.strip().replace("(", "").replace(")", "").replace(" ", "")
            parts = line.split(",")
            if len(parts) >= 2:
                try:
                    lon = float(parts[0])
                    lat = float(parts[1])
                    coords.append((lon, lat))
                except ValueError:
                    continue
    else:
        df = pd.read_csv(depot_csv)
        coords = list(zip(df["Longitude"], df["Latitude"]))

    depot_df = pd.DataFrame(coords, columns=["Longitude", "Latitude"])
    if depot_df["Longitude"].abs().max() <= 90 and depot_df["Latitude"].abs().max() > 90:
        print("⚠️ Detected flipped coordinates — swapping Latitude/Longitude.")
        depot_df = depot_df.rename(columns={"Longitude": "Latitude", "Latitude": "Longitude"})

    depot_gdf = gpd.GeoDataFrame(
        depot_df,
        geometry=gpd.points_from_xy(depot_df["Longitude"], depot_df["Latitude"]),
        crs="EPSG:4326"
    ).to_crs(epsg=3857)

    print(f"Loaded {len(routes_gdf)} route features")
    print(f"Loaded {len(depot_gdf)} depot points before filtering")

    route_union = routes_gdf.buffer(BUFFER_METERS).unary_union
    depot_gdf = depot_gdf[depot_gdf.intersects(route_union)]
    print(f"{len(depot_gdf)} depots remain after proximity filter")

    return routes_gdf, depot_gdf

# =====================
# BUILD GRAPH
# =====================
def build_graph_from_routes(gdf):
    print("Building network graph from routes...")
    G = nx.Graph()
    for _, row in gdf.iterrows():
        geom = row.geometry
        if geom is None:
            continue
        geom_type = getattr(geom, "geom_type", None)
        if geom_type == "LineString":
            lines = [geom]
        elif geom_type == "MultiLineString":
            lines = list(geom.geoms)
        else:
            continue
        for line in lines:
            coords = list(line.coords)
            for i in range(len(coords) - 1):
                u, v = coords[i], coords[i + 1]
                d = euclid(u, v)
                if G.has_edge(u, v):
                    if d < G[u][v].get("weight", np.inf):
                        G[u][v]["weight"] = d
                else:
                    G.add_edge(u, v, weight=d)
    pos_map = {n: n for n in G.nodes()}
    nx.set_node_attributes(G, pos_map, "pos")
    print(f"Graph built with {G.number_of_nodes()} nodes and {G.number_of_edges()} edges")
    return G

# =====================
# CONNECT SUBNETWORKS
# =====================
def connect_subnetworks(G, max_k=10):
    from scipy.spatial import cKDTree
    print("\nConnecting subnetworks...")
    comps = list(nx.connected_components(G))
    print(f"Initial subnetworks: {len(comps)}")
    if len(comps) <= 1:
        return G, gpd.GeoDataFrame(columns=["geometry"], crs="EPSG:3857")
    added_edges = []
    iteration = 0
    while len(comps) > 1 and iteration < MAX_CONNECT_ITER:
        centroids = [np.mean(np.array(list(c)), axis=0) for c in comps]
        tree = cKDTree(centroids)
        dists, idxs = tree.query(centroids, k=min(max_k, len(centroids)))
        min_dist = float("inf")
        best_pair = None
        for i, comp_a in enumerate(comps):
            for j in np.atleast_1d(idxs[i]):
                if i == j or j >= len(comps):
                    continue
                comp_b = comps[j]
                a_nodes = np.array(list(comp_a))
                b_nodes = np.array(list(comp_b))
                tree_b = cKDTree(b_nodes)
                dist, idx_b = tree_b.query(a_nodes)
                min_idx = np.argmin(dist)
                d = dist[min_idx]
                if d < min_dist:
                    min_dist = d
                    best_pair = (tuple(a_nodes[min_idx]), tuple(b_nodes[idx_b[min_idx]]))
        if best_pair:
            u, v = best_pair
            G.add_edge(u, v, weight=min_dist, artificial=True)
            added_edges.append(LineString([u, v]))
            comps = list(nx.connected_components(G))
            iteration += 1
            if iteration % 50 == 0 or iteration <= 5:
                print(f"  Connected 2 subnetworks -> now {len(comps)} remain")
        else:
            print("No suitable pair found — breaking.")
            break
    bridge_gdf = gpd.GeoDataFrame(geometry=added_edges, crs="EPSG:3857")
    print(f"✅ All subnetworks connected. Added {len(added_edges)} bridge edges.")
    return G, bridge_gdf

# =====================
# CONNECT DEPOTS TO GRAPH
# =====================
def connect_depots_to_graph(G, depot_gdf):
    depot_nodes = []
    for _, depot in depot_gdf.iterrows():
        depot_point = (depot.geometry.x, depot.geometry.y)
        nearest_node = min(G.nodes, key=lambda n: euclid((n[0], n[1]), depot_point))
        dist = euclid(nearest_node, depot_point)
        if depot_point not in G:
            G.add_node(depot_point)
            nx.set_node_attributes(G, {depot_point: depot_point}, "pos")
        G.add_edge(depot_point, nearest_node, weight=dist)
        depot_nodes.append(depot_point)
    print(f"Connected {len(depot_nodes)} depots to network.")
    return depot_nodes

# =====================
# PREPARE ORIENTED EDGES & ADJACENCY
# =====================
def make_oriented_edges(G):
    oriented_edges = []
    edge_weight = {}
    for (u, v, data) in G.edges(data=True):
        w = data.get("weight", euclid(u, v))
        oriented_edges.append((u, v))
        edge_weight[(u, v)] = w
        oriented_edges.append((v, u))
        edge_weight[(v, u)] = w
    start_map = defaultdict(list)
    for idx, (a, b) in enumerate(oriented_edges):
        start_map[a].append(idx)
    return oriented_edges, start_map, edge_weight

# =====================
# PLOT RESULTS IN LAT/LON
# =====================
def plot_results_multi(routes_gdf, depot_gdf, results, depot_nodes, style_params=None):
    """
    Plot multi-depot ACO results in latitude/longitude coordinates.
    - Depots as true circles labeled A, B, C...
    - Circle edge color matches depot route color
    - Each depot labeled with its lat/lon in a boxed label offset upward/right
    - Customizable axis limits while keeping equal aspect
    """
    import string
    import pyproj
    from matplotlib.patches import Circle
    import matplotlib.pyplot as plt

    # Default style params
    style_params = style_params or {}
    circle_radius_m = style_params.get("circle_radius_m", 2000)
    alpha = style_params.get("line_alpha", 0.7)
    linewidth = style_params.get("line_width", 2.2)
    coord_offset_deg = style_params.get("coord_offset_deg", (0.015, 0.012))
    label_offset_points_x = style_params.get("label_offset_points_x", 14)
    label_offset_points_y = style_params.get("label_offset_points_y", 10)

    # Optional axis limits
    xlim = style_params.get("xlim", None)  # tuple (min_lon, max_lon)
    ylim = style_params.get("ylim", None)  # tuple (min_lat, max_lat)

    cmap = plt.colormaps.get_cmap("tab10")
    depot_letters = string.ascii_uppercase

    # Convert routes_gdf to lat/lon
    routes_latlon = routes_gdf.to_crs(epsg=4326)

    # CRS transformer: from EPSG:3857 → EPSG:4326
    transformer = pyproj.Transformer.from_crs(3857, 4326, always_xy=True)

    fig, ax = plt.subplots(figsize=(14, 12))
    routes_latlon.plot(ax=ax, color="lightgray", linewidth=1.2, alpha=0.8, zorder=1)

    # Keep aspect equal but adjustable (allows manual axis limits)
    ax.set_aspect("equal", adjustable="box")

    # Plot depots
    for depot_idx, depot_node in enumerate(depot_nodes):
        color = cmap(depot_idx % cmap.N)
        x, y = depot_node
        lon, lat = transformer.transform(x, y)

        # Draw circular depot
        circle = Circle(
            (lon, lat),
            circle_radius_m * 0.00001,  # approximate meters->degrees
            edgecolor=color,
            facecolor="white",
            linewidth=2.5,
            zorder=5
        )
        ax.add_patch(circle)

        # Letter label in circle
        ax.text(lon, lat, depot_letters[depot_idx % len(depot_letters)],
                fontsize=12, fontweight="bold",
                ha="center", va="center",
                color=color, zorder=6)

        # Coordinate label with offset and box
        ax.annotate(
            f"{lat:.5f}, {lon:.5f}",
            xy=(lon, lat),
            xytext=(label_offset_points_x, label_offset_points_y),
            textcoords="offset points",
            fontsize=9,
            color="black",
            zorder=8,
            bbox=dict(facecolor="white", edgecolor="gray", boxstyle="round,pad=0.3", alpha=0.95),
            ha="left",
            va="bottom"
        )

    # Draw vehicle routes
    for entry in results:
        depot_idx, vehicle_routes, *_ = entry
        color = cmap(depot_idx % cmap.N)
        for vnum, vehicle_edges, _, _ in vehicle_routes:
            for u, v in vehicle_edges:
                lon_u, lat_u = transformer.transform(u[0], u[1])
                lon_v, lat_v = transformer.transform(v[0], v[1])
                ax.plot([lon_u, lon_v], [lat_u, lat_v],
                        color=color, alpha=alpha, linewidth=linewidth, zorder=3)

    # Axis labels and title
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Multi-Depot Multi-Vehicle ACO Results (Lat/Lon)", fontsize=16)

    # Apply optional axis limits (zoom)
    if xlim:
        ax.set_xlim(*xlim)
    if ylim:
        ax.set_ylim(*ylim)

    plt.tight_layout()
    plt.show()



# =====================
# MULTI-DEPOT MULTI-VEHICLE ACO
# =====================
# (Use your existing ACO code as-is)
def multi_depot_multi_vehicle_aco(
    G, depot_nodes, oriented_edges, start_map, edge_weight,
    vehicles_per_depot=2, n_ants=12, n_iter=20,
    alpha=0.5, beta=5.0, rho=0.1,
    start_radius=8, teleport_max_dist_m=50000):
    """
    Multi-depot multi-vehicle ACO with progressive CSV saving.
    Each depot's results are appended to a shared output file as the algorithm runs.
    """
    epsilon = 1e-12
    oriented_index_map = {edge: i for i, edge in enumerate(oriented_edges)}
    total_edges = len(oriented_edges)

    global AVERAGE_SPEED_KMH

    # File setup for progressive saving
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    csv_path = Path(__file__).parent / f"ACO_summary_progress_{timestamp}.csv"

    # Undirected edge mapping (unique coverage)
    undirected_weight = {}
    oriented_to_undirected = {}
    for i, (u, v) in enumerate(oriented_edges):
        key = tuple(sorted((u, v)))
        oriented_to_undirected[i] = key
        if key not in undirected_weight:
            undirected_weight[key] = edge_weight.get((u, v), euclid(u, v))

    def nearby_edges(G, depot_node, radius):
        visited_nodes = {depot_node}
        queue = [(depot_node, 0)]
        nearby = []
        while queue:
            node, dist = queue.pop(0)
            if dist < radius:
                for nb in G.neighbors(node):
                    if nb not in visited_nodes:
                        visited_nodes.add(nb)
                        queue.append((nb, dist + 1))
                    for e in [(node, nb), (nb, node)]:
                        if e in oriented_index_map:
                            nearby.append(oriented_index_map[e])
        return list(dict.fromkeys(nearby))

    global_tau = {i: 1.0 for i in range(total_edges)}
    global_covered_oriented = set()
    global_covered_undirected = set()
    results = []

    for depot_idx, depot_node in enumerate(depot_nodes):
        print(f"\n--- Depot {depot_idx + 1}/{len(depot_nodes)} ---")

        # determine start edges (oriented indices)
        if start_map and depot_node in start_map and start_map[depot_node]:
            start_edges = list(start_map[depot_node])
        else:
            start_edges = nearby_edges(G, depot_node, start_radius)
        if not start_edges:
            nearest_edge = min(oriented_edges, key=lambda e: euclid(e[0], depot_node))
            start_edges = [oriented_index_map[nearest_edge]]

        depot_covered_oriented = set()
        depot_covered_undirected = set()
        vehicle_routes = []

        for vehicle_num in range(vehicles_per_depot):
            print(f"\n🚚 Vehicle {vehicle_num+1} starting from Depot {depot_idx+1}")
            vehicle_oriented_set = set()
            vehicle_undirected_set = set()

            for iteration in range(1, n_iter + 1):
                ant_routes = []
                ant_scores = []

                for ant in range(n_ants):
                    current_idx = random.choice(start_edges)
                    route = [current_idx]
                    visited = set(route)
                    steps = 0

                    while True:
                        steps += 1
                        if steps > STEPS:
                            break

                        current_end = oriented_edges[current_idx][1]
                        if current_end not in G:
                            break

                        neighbors = list(G.neighbors(current_end))
                        candidates = []
                        for nb in neighbors:
                            for e in [(current_end, nb), (nb, current_end)]:
                                if e in oriented_index_map:
                                    e_idx = oriented_index_map[e]
                                    if e_idx not in visited or e_idx not in global_covered_oriented:
                                        candidates.append(e_idx)

                        if not candidates:
                            uncovered_edges = [e for e in range(total_edges) if e not in global_covered_oriented]
                            if not uncovered_edges:
                                break
                            min_dist = float("inf")
                            chosen_uncovered = None
                            for e in uncovered_edges:
                                start_node = oriented_edges[e][0]
                                d = euclid(current_end, start_node)
                                if d < min_dist:
                                    min_dist = d
                                    chosen_uncovered = e
                            if chosen_uncovered is not None and min_dist <= teleport_max_dist_m:
                                current_idx = chosen_uncovered
                                route.append(current_idx)
                                visited.add(current_idx)
                                continue
                            else:
                                break

                        phs = np.array([global_tau[c] for c in candidates], dtype=float)
                        lengths = np.array([edge_weight.get(oriented_edges[c], euclid(*oriented_edges[c])) for c in candidates], dtype=float)
                        heur = 1.0 / np.maximum(lengths, epsilon)
                        unvisited_boost = np.array([50.0 if c not in global_covered_oriented else 0.2 for c in candidates])
                        probs_raw = (phs ** alpha) * (heur ** beta) * unvisited_boost
                        total_prob = probs_raw.sum()

                        if total_prob <= 0 or np.isnan(total_prob):
                            chosen = random.choice(candidates)
                        else:
                            probs = probs_raw / total_prob
                            probs = np.maximum(probs, 0)
                            s = probs.sum()
                            if s <= 0 or np.isnan(s):
                                chosen = random.choice(candidates)
                            else:
                                probs = probs / s
                                chosen = np.random.choice(candidates, p=probs)

                        route.append(chosen)
                        visited.add(chosen)
                        current_idx = chosen
                        if len(route) > 7000:
                            break

                    total_distance_m = sum(edge_weight.get(oriented_edges[e], euclid(*oriented_edges[e])) for e in route)
                    unique_undirected_keys = set(oriented_to_undirected[e] for e in route)
                    unique_distance_m = sum(undirected_weight[k] for k in unique_undirected_keys)
                    ant_routes.append({
                        "route_oriented": route,
                        "total_distance_m": total_distance_m,
                        "unique_undirected_keys": unique_undirected_keys,
                        "unique_distance_m": unique_distance_m
                    })
                    ant_scores.append(total_distance_m)

                if ant_scores:
                    best_idx = int(np.argmax(ant_scores))
                    ant_best = ant_routes[best_idx]
                    ant_best_route_oriented = ant_best["route_oriented"]

                    for e_idx in ant_best_route_oriented:
                        global_tau[e_idx] = (1 - rho) * global_tau.get(e_idx, 1.0) + rho * ant_scores[best_idx]

                    vehicle_oriented_set.update(ant_best_route_oriented)
                    vehicle_undirected_set.update(oriented_to_undirected[e] for e in ant_best_route_oriented)
                    depot_covered_oriented.update(ant_best_route_oriented)
                    depot_covered_undirected.update(oriented_to_undirected[e] for e in ant_best_route_oriented)
                    global_covered_oriented.update(ant_best_route_oriented)
                    global_covered_undirected.update(oriented_to_undirected[e] for e in ant_best_route_oriented)

                if iteration % max(1, n_iter // 10) == 0:
                    print(f"  Iter {iteration:03d}: global (oriented) coverage {len(global_covered_oriented)}/{total_edges} "
                          f" | global (unique undirected) {len(global_covered_undirected)}")

                if len(global_covered_oriented) >= total_edges:
                    break

            vehicle_unique_distance_m = sum(undirected_weight[k] for k in vehicle_undirected_set)
            vehicle_routes.append((vehicle_num, list(vehicle_undirected_set), vehicle_unique_distance_m, len(vehicle_undirected_set)))

        total_unique_distance_depot_m = sum(undirected_weight[k] for k in depot_covered_undirected)
        total_unique_distance_km = total_unique_distance_depot_m / 1000.0
        avg_unique_distance_per_vehicle_m = total_unique_distance_depot_m / vehicles_per_depot
        avg_time_per_vehicle_h = (total_unique_distance_km / vehicles_per_depot) / AVERAGE_SPEED_KMH

        results.append((depot_idx, vehicle_routes, len(global_covered_oriented),
                        total_edges, total_unique_distance_depot_m, avg_time_per_vehicle_h,
                        avg_unique_distance_per_vehicle_m))

        print(f"🏁 Depot {depot_idx+1} done: Unique coverage {total_unique_distance_km:.2f} km total, "
              f"~{avg_unique_distance_per_vehicle_m/1000:.2f} km/vehicle")

        # --- Progressive CSV writing ---
        depot_records = []
        for vnum, vehicle_edges, dist_m, n_edges in vehicle_routes:
            depot_records.append({
                "Level": "Vehicle",
                "Depot": depot_idx + 1,
                "Vehicle": vnum + 1,
                "Unique_Edges": n_edges,
                "Unique_Distance_km": dist_m / 1000.0,
                "Total_Unique_Distance_km": "",
                "Avg_Time_per_Vehicle_h": "",
                "Avg_Distance_per_Vehicle_km": ""
            })
        depot_records.append({
            "Level": "Depot",
            "Depot": depot_idx + 1,
            "Vehicle": "",
            "Unique_Edges": len(depot_covered_undirected),
            "Unique_Distance_km": "",
            "Total_Unique_Distance_km": total_unique_distance_depot_m / 1000.0,
            "Avg_Time_per_Vehicle_h": avg_time_per_vehicle_h,
            "Avg_Distance_per_Vehicle_km": avg_unique_distance_per_vehicle_m / 1000.0
        })

        df_new = pd.DataFrame(depot_records)
        if not csv_path.exists():
            df_new.to_csv(csv_path, index=False)
        else:
            df_new.to_csv(csv_path, index=False, mode="a", header=False)
        print(f"💾 Saved progress for Depot {depot_idx + 1} to {csv_path}")

        if len(global_covered_oriented) >= total_edges:
            break

    print(f"\n✅ FINAL GLOBAL COVERAGE: {len(global_covered_oriented)}/{total_edges}")
    print(f"✅ FINAL UNIQUE UNDIRECTED COVERAGE: {len(global_covered_undirected)}")
    print(f"📁 All progress saved to {csv_path}")
    return results
# =====================
# PLOTTING CACHED FINAL GRAPH
# =====================
def plot_cached_final_graph(cache_path, routes_gdf, depot_gdf):
    with open(cache_path, "rb") as f:
        data = pickle.load(f)
    G = data["G"]
    depot_nodes = data["depot_nodes"]
    results = data["results"]
    style_params = data.get("style_params", {})
    plot_results_multi(routes_gdf, depot_gdf, results, depot_nodes, style_params=style_params)
    
# =====================
# MAIN
# =====================
def main():
    routes_gdf, depot_gdf = load_routes_and_depots(GEOJSON_PATH, DEPOT_TXT_PATH)

    print("\nPlotting initial map (before ACO)...")
    fig, ax = plt.subplots(figsize=(12, 10))
    routes_gdf.plot(ax=ax, color="lightgray", linewidth=1.2, alpha=0.9)
    if not depot_gdf.empty:
        depot_gdf.plot(ax=ax, color="orange", markersize=50, edgecolor="black")
    ax.set_aspect("equal")
    ax.set_title("Initial Road Network and Depots")
    plt.tight_layout()
    plt.show()

    G = build_graph_from_routes(routes_gdf)

    bridge_gdf = gpd.GeoDataFrame(geometry=[], crs="EPSG:3857")
    rebuild = FORCE_RECONNECT_SUBNETWORKS or not GRAPH_CACHE_PATH.exists()
    if not rebuild:
        try:
            with open(GRAPH_CACHE_PATH, "rb") as f:
                G, bridge_gdf = pickle.load(f)
            print("✅ Loaded cached connected graph")
        except:
            rebuild = True
    if rebuild:
        G, bridge_gdf = connect_subnetworks(G)
        with open(GRAPH_CACHE_PATH, "wb") as f:
            pickle.dump((G, bridge_gdf), f)
        print(f"✅ Saved connected graph to {GRAPH_CACHE_PATH}")

    depot_nodes = connect_depots_to_graph(G, depot_gdf)
    oriented_edges, start_map, edge_weight = make_oriented_edges(G)

    # -------------------------
    # Check if cached final graph exists
    # -------------------------
    if FINAL_GRAPH_CACHE_PATH.exists():
        print("✅ Loading cached final graph...")
        plot_cached_final_graph(FINAL_GRAPH_CACHE_PATH, routes_gdf, depot_gdf)
        return

    # -------------------------
    # Run ACO if no cached final graph
    # -------------------------
    if ACO_ENABLED and len(depot_nodes) > 0:
        results = multi_depot_multi_vehicle_aco(
            G, depot_nodes, oriented_edges, start_map, edge_weight,
            vehicles_per_depot=VEHICLES_PER_DEPOT,
            n_ants=N_ANTS, n_iter=N_ITERATIONS,
        )

        # Save final graph
        style_params = {
            "circle_radius_m": 2000,
            "line_alpha": 0.7,
            "line_width": 2.2,
            "coord_offset_deg": (0.01, 0.01)
        }
        with open(FINAL_GRAPH_CACHE_PATH, "wb") as f:
            pickle.dump({"G": G, "depot_nodes": depot_nodes, "results": results, "style_params": style_params}, f)
        print(f"✅ Final graph saved to {FINAL_GRAPH_CACHE_PATH}")

        # Plot final results
        plot_results_multi(routes_gdf, depot_gdf, results, depot_nodes, style_params=style_params)
    else:
        print("ACO disabled or no depots found.")

if __name__ == "__main__":
    main()
