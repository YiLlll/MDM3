import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
from shapely.geometry import LineString
from shapely.ops import substring
from sklearn.cluster import KMeans
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# ============================================================================
# CONFIGURATION PARAMETERS
# ============================================================================

ROADS_PATH = "england_complete_road_network.geojson"
SAMPLE_STEP_M = 100                 # Sampling interval in meters
TIME_BUDGET_H = 2.0                 # Maximum work time per vehicle (hours)
MAX_TASK_LENGTH_KM = 47.0           # Maximum task length constraint (km)
WORK_SPEED_KMH = 80                 # Working speed (km/h)
TRAVEL_SPEED_KMH = 80               # Travel speed (km/h)
DETOUR_FACTOR = 1.30                # Detour factor (gamma)
MAX_VEH_PER_DEPOT = 20              # Maximum vehicles per depot

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def to_bng(gdf):
    """
    Convert GeoDataFrame to British National Grid (EPSG:27700) projection.
    
    Args:
        gdf: Input GeoDataFrame
        
    Returns:
        GeoDataFrame in EPSG:27700 projection
    """
    if gdf.crs is None:
        gdf = gdf.set_crs(4326)
    return gdf.to_crs(27700)


def sample_points(line: LineString, step: int):
    """
    Sample points along a LineString at regular intervals.
    
    Args:
        line: Input LineString geometry
        step: Sampling interval in meters
        
    Returns:
        List of Point geometries
    """
    if line.length <= 0:
        return []
    dists = np.arange(step/2, line.length, step)
    return [line.interpolate(d) for d in dists]


def segment_long_roads(line: LineString, max_length_km: float):
    """
    Segment roads longer than the maximum length constraint.
    Preserves the original curve shape by using actual distance.
    
    Args:
        line: Input LineString geometry
        max_length_km: Maximum segment length in kilometers
        
    Returns:
        List of segmented LineString geometries
    """
    max_len = max_length_km * 1000.0
    L = line.length
    if L <= max_len:
        return [line]
    
    segments = []
    start = 0.0
    while start < L:
        end = min(start + max_len, L)
        # Extract subsegment using actual distance (not normalized)
        segments.append(substring(line, start, end, normalized=False))
        start = end
    return segments

# ============================================================================
# OPTIMIZATION ALGORITHMS
# ============================================================================

def vehicles_needed_with_spatial_split(npts, R80_m, T_h, S_m, v_work_kmh, v_travel_kmh, gamma, m_cap):
    """
    Calculate minimum number of vehicles needed using spatial split optimization.
    Uses R80/√m scaling approximation to find the minimum m (vehicles) such that
    the worst-case vehicle time ≤ T_h.
    
    Args:
        npts: Number of sample points in cluster
        R80_m: 80th percentile radius in meters
        T_h: Time budget in hours
        S_m: Sampling interval in meters
        v_work_kmh: Working speed in km/h
        v_travel_kmh: Travel speed in km/h
        gamma: Detour factor
        m_cap: Maximum vehicles allowed
        
    Returns:
        Tuple of (vehicles_needed, worst_case_time, travel_time)
        Returns (inf, inf, inf) if no feasible solution exists
    """
    # Convert speeds to m/s
    v_work_mps = v_work_kmh * 1000 / 3600.0
    v_travel_mps = v_travel_kmh * 1000 / 3600.0
    
    for m in range(1, m_cap + 1):
        # Sub-cluster 80th percentile radius approximation
        R80_sub = R80_m / np.sqrt(m)
        travel_h = (gamma * 2.0 * R80_sub) / v_travel_mps / 3600.0
        work_budget_h = T_h - travel_h
        
        if work_budget_h <= 0:
            continue
        
        # Maximum points per vehicle given work budget
        pts_per_vehicle_max = int(np.floor(work_budget_h * v_work_mps * 3600.0 / S_m))
        if pts_per_vehicle_max <= 0:
            continue
        
        # Minimum vehicles needed for discrete point distribution
        m_needed = int(np.ceil(npts / pts_per_vehicle_max))
        if m_needed <= m:
            # Calculate worst-case vehicle workload
            worst_pts = int(np.floor(npts / m)) + (1 if (npts % m) > 0 else 0)
            work_h_worst = (worst_pts * S_m) / v_work_mps / 3600.0
            per_vehicle_worst_h = work_h_worst + travel_h
            
            if per_vehicle_worst_h <= T_h:
                return m, per_vehicle_worst_h, travel_h
    
    return np.inf, np.inf, np.inf


def calculate_depot_stats(X, centers, labels, K):
    """
    Calculate statistics for each depot cluster including vehicle requirements.
    
    Args:
        X: Array of sample point coordinates
        centers: Array of cluster center coordinates
        labels: Array of cluster labels for each point
        K: Number of clusters
        
    Returns:
        Tuple of (stats_list, feasible_clusters_count, total_vehicles_needed)
    """
    stats = []
    total_vehicles_needed = 0
    feasible_clusters = 0
    
    for k in range(K):
        idx = np.where(labels == k)[0]
        npts = len(idx)
        
        # Handle empty clusters
        if npts == 0:
            stats.append({
                "cluster": k, 
                "points": 0,
                "vehicles_needed": 0,
                "work_h_per_vehicle": 0.0, 
                "travel_h_per_vehicle": 0.0, 
                "total_h_per_vehicle": 0.0,
                "feasible": True
            })
            feasible_clusters += 1
            continue

        P = X[idx]
        C = centers[k]

        # Calculate R80 (80th percentile radius) for current cluster
        dists = np.linalg.norm(P - C, axis=1)
        R80_m = float(np.quantile(dists, 0.8)) if len(dists) > 0 else 0.0
        
        # Calculate required vehicles using spatial split method
        m_needed, worst_h, travel_h = vehicles_needed_with_spatial_split(
            npts=npts,
            R80_m=R80_m,
            T_h=TIME_BUDGET_H,
            S_m=SAMPLE_STEP_M,
            v_work_kmh=WORK_SPEED_KMH,
            v_travel_kmh=TRAVEL_SPEED_KMH,
            gamma=DETOUR_FACTOR,
            m_cap=MAX_VEH_PER_DEPOT
        )
        
        # Determine feasibility
        feasible = m_needed < np.inf and m_needed <= MAX_VEH_PER_DEPOT
        
        if feasible:
            feasible_clusters += 1
            total_vehicles_needed += m_needed
            
            # Calculate actual work time per vehicle
            if m_needed > 0:
                pts_per_vehicle = npts / m_needed
                work_h_per_vehicle = (pts_per_vehicle * SAMPLE_STEP_M / 
                                    (WORK_SPEED_KMH * 1000 / 3600) / 3600.0)
                total_h_per_vehicle = work_h_per_vehicle + travel_h
            else:
                work_h_per_vehicle = 0
                total_h_per_vehicle = 0
        else:
            m_needed = 0
            work_h_per_vehicle = 0
            travel_h = 0
            total_h_per_vehicle = 0

        stats.append({
            "cluster": k,
            "points": npts,
            "vehicles_needed": m_needed,
            "work_h_per_vehicle": work_h_per_vehicle,
            "travel_h_per_vehicle": travel_h,
            "total_h_per_vehicle": total_h_per_vehicle,
            "feasible": feasible
        })
    
    return stats, feasible_clusters, total_vehicles_needed

# ============================================================================
# VISUALIZATION FUNCTIONS
# ============================================================================

def plot_existing_vs_optimized_comparison(best_config_data, optimized_depot_df):
    """
    Generate comparison map showing existing depots vs optimized depot locations.
    
    Args:
        best_config_data: Dictionary containing best configuration data
        optimized_depot_df: DataFrame with optimized depot coordinates
    """
    print("\n" + "=" * 80)
    print("Generating Depot Network Comparison Map")
    print("=" * 80)
    
    # Load existing depot data
    try:
        existing_depots = pd.read_csv("depot_details.csv")
        # Filter out invalid coordinates and non-operational depots
        existing_depots = existing_depots[
            (existing_depots['Latitude'] != 0) & 
            (existing_depots['Longitude'] != 0) & 
            (existing_depots['Operational?'] == 'Y')
        ].copy()
        
        if len(existing_depots) == 0:
            print("WARNING: No valid existing depot coordinates found. Skipping comparison.")
            return
        
        # Convert to GeoDataFrame (WGS84 -> BNG)
        existing_gdf = gpd.GeoDataFrame(
            existing_depots,
            geometry=gpd.points_from_xy(existing_depots['Longitude'], 
                                       existing_depots['Latitude']),
            crs=4326
        )
        existing_gdf = existing_gdf.to_crs(27700)
        
        print(f"Loaded {len(existing_gdf)} existing operational depots")
        
    except Exception as e:
        print(f"ERROR: Failed to load existing depots - {e}")
        return
    
    # Load road network data
    print("Loading road network...")
    roads = gpd.read_file(ROADS_PATH)
    roads = to_bng(roads)
    roads = roads[roads.geometry.notna() & 
                 roads.geometry.type.isin(["LineString", "MultiLineString"])]
    
    # Create comparison figure
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(24, 10))
    
    # Left plot: Existing depot network
    roads.plot(ax=ax1, color='#4A90E2', linewidth=0.5, alpha=0.7, 
              label='Road Network')
    
    ax1.scatter(existing_gdf.geometry.x, existing_gdf.geometry.y,
               c='green', s=100, alpha=0.8, edgecolors='darkgreen',
               linewidth=2, marker='o', 
               label=f'Existing Depots (n={len(existing_gdf)})', zorder=5)
    
    ax1.set_title('Current Depot Network', fontsize=16, fontweight='bold')
    ax1.set_xlabel('Easting (m) [EPSG:27700]', fontsize=12)
    ax1.set_ylabel('Northing (m)', fontsize=12)
    ax1.grid(True, alpha=0.3)
    ax1.legend(loc='upper right', fontsize=11)
    
    # Right plot: Optimized depot network
    roads.plot(ax=ax2, color='#4A90E2', linewidth=0.5, alpha=0.7, 
              label='Road Network')
    
    scatter = ax2.scatter(optimized_depot_df['easting'], 
                         optimized_depot_df['northing'],
                         c=optimized_depot_df['vehicles_needed'],
                         s=100, cmap='Reds', alpha=0.8, edgecolors='darkred',
                         linewidth=2, marker='^', 
                         label=f'Optimized Depots (n={len(optimized_depot_df)})', 
                         zorder=5)
    
    ax2.set_title(f'Optimized Depot Network (K={best_config_data["K"]})', 
                  fontsize=16, fontweight='bold')
    ax2.set_xlabel('Easting (m) [EPSG:27700]', fontsize=12)
    ax2.set_ylabel('Northing (m)', fontsize=12)
    ax2.grid(True, alpha=0.3)
    ax2.legend(loc='upper right', fontsize=11)
    
    # Add colorbar
    cbar = plt.colorbar(scatter, ax=ax2, shrink=0.8)
    cbar.set_label('Vehicles per Depot', fontsize=12)
    
    plt.suptitle('Depot Network Comparison: Existing vs Optimized', 
                fontsize=18, fontweight='bold', y=0.98)
    plt.tight_layout()
    plt.show()
    
    # Print comparison statistics
    print("\n" + "=" * 80)
    print("Comparison Statistics")
    print("=" * 80)
    print(f"\nExisting Network:")
    print(f"  - Number of Depots: {len(existing_gdf)}")
    print(f"\nOptimized Network:")
    print(f"  - Number of Depots: {len(optimized_depot_df)}")
    print(f"  - Total Vehicles Needed: {optimized_depot_df['vehicles_needed'].sum()}")
    print(f"  - Avg Vehicles per Depot: {optimized_depot_df['vehicles_needed'].mean():.1f}")
    depot_change = len(optimized_depot_df) - len(existing_gdf)
    depot_change_pct = (depot_change / len(existing_gdf) * 100)
    print(f"  - Change in Depot Count: {depot_change:+d} ({depot_change_pct:+.1f}%)")


def plot_road_network_with_depots(best_config_data, depot_df):
    """
    Generate detailed visualization of road network and optimized depot locations.
    
    Args:
        best_config_data: Dictionary containing best configuration data
        depot_df: DataFrame with depot coordinates and statistics
    """
    print("\n" + "=" * 80)
    print("Generating Road Network and Depot Distribution Maps")
    print("=" * 80)
    
    # Load road network data
    roads = gpd.read_file(ROADS_PATH)
    roads = to_bng(roads)
    roads = roads[roads.geometry.notna() & 
                 roads.geometry.type.isin(["LineString", "MultiLineString"])]
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 10))
    
    # Left plot: Full road network with depot locations
    roads.plot(ax=ax1, color='#4A90E2', linewidth=0.5, alpha=0.7, 
              label='Road Network')
    
    scatter = ax1.scatter(depot_df['easting'], depot_df['northing'], 
                         c=depot_df['vehicles_needed'], 
                         s=50, cmap='Reds', alpha=0.8, 
                         edgecolors='darkred', linewidth=1,
                         label='Optimized Depots')
    
    ax1.set_title(f'Road Network & Optimal Depot Locations (K={best_config_data["K"]})', 
                  fontsize=14, fontweight='bold')
    ax1.set_xlabel('Easting (m) [EPSG:27700]')
    ax1.set_ylabel('Northing (m)')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    cbar = plt.colorbar(scatter, ax=ax1, shrink=0.8)
    cbar.set_label('Vehicles per Depot', fontsize=12)
    
    # Right plot: Detailed depot distribution (zoomed)
    center_x = depot_df['easting'].mean()
    center_y = depot_df['northing'].mean()
    
    if len(depot_df) > 0:
        margin = max(depot_df['easting'].std(), depot_df['northing'].std()) * 2
        if margin == 0:
            margin = 1000
        ax2.set_xlim(center_x - margin, center_x + margin)
        ax2.set_ylim(center_y - margin, center_y + margin)
    
    roads.plot(ax=ax2, color='#6B7280', linewidth=0.6, alpha=0.6)
    
    # Variable depot size based on vehicle count
    sizes = depot_df['vehicles_needed'] * 20 + 30
    scatter2 = ax2.scatter(depot_df['easting'], depot_df['northing'], 
                          c=depot_df['vehicles_needed'], 
                          s=sizes, cmap='Reds', alpha=0.8, 
                          edgecolors='darkred', linewidth=1.5)
    
    # Add depot ID labels (top 20 to avoid clutter)
    for i, row in depot_df.head(20).iterrows():
        ax2.annotate(f"{row['depot_id']}", 
                    (row['easting'], row['northing']),
                    xytext=(5, 5), textcoords='offset points',
                    fontsize=8, color='black', fontweight='bold',
                    bbox=dict(boxstyle="round,pad=0.2", 
                             facecolor='white', alpha=0.7))
    
    ax2.set_title(f'Depot Details (Vehicles & IDs) - K={best_config_data["K"]}', 
                  fontsize=14, fontweight='bold')
    ax2.set_xlabel('Easting (m) [EPSG:27700]')
    ax2.set_ylabel('Northing (m)')
    ax2.grid(True, alpha=0.3)
    
    cbar2 = plt.colorbar(scatter2, ax=ax2, shrink=0.8)
    cbar2.set_label('Vehicles per Depot', fontsize=12)
    
    plt.tight_layout()
    plt.show()
    
    # Print depot statistics
    print("\n" + "=" * 80)
    print("Depot Distribution Statistics")
    print("=" * 80)
    print(f"Total Depots: {len(depot_df)}")
    
    if len(depot_df) > 0:
        print(f"Total Vehicles: {depot_df['vehicles_needed'].sum()}")
        print(f"Avg Vehicles per Depot: {depot_df['vehicles_needed'].mean():.1f}")
        print(f"Max Vehicles per Depot: {depot_df['vehicles_needed'].max()}")
        print(f"Min Vehicles per Depot: {depot_df['vehicles_needed'].min()}")
        print(f"Avg Work Time per Vehicle: {depot_df['total_h_per_vehicle'].mean():.2f} hours")
        print(f"Max Work Time per Vehicle: {depot_df['total_h_per_vehicle'].max():.2f} hours")
    else:
        print("No depot data available")


def save_best_config_coordinates(best_config_data, best_config):
    """
    Save optimal depot configuration coordinates and statistics to CSV.
    
    Args:
        best_config_data: Dictionary containing best configuration data
        best_config: Series containing best configuration parameters
    """
    K = best_config_data["K"]
    centers = best_config_data["centers"]
    stats = best_config_data["stats"]
    
    # Create depot coordinates DataFrame
    depot_coords = []
    for i, (center, stat) in enumerate(zip(centers, stats)):
        depot_coords.append({
            "depot_id": i,
            "easting": center[0],
            "northing": center[1],
            "points_count": stat["points"],
            "vehicles_needed": stat["vehicles_needed"],
            "work_h_per_vehicle": stat["work_h_per_vehicle"],
            "travel_h_per_vehicle": stat["travel_h_per_vehicle"],
            "total_h_per_vehicle": stat["total_h_per_vehicle"],
            "feasible": stat["feasible"]
        })
    
    depot_df = pd.DataFrame(depot_coords)
    
    # Save to CSV
    output_file = f"best_config_K{K}_depot_coordinates.csv"
    depot_df.to_csv(output_file, index=False)
    print(f"\nOptimal depot coordinates saved to: {output_file}")
    
    # Display top 10 depot coordinates
    print("\n" + "=" * 80)
    print("Top 10 Depot Coordinates (EPSG:27700 British National Grid)")
    print("=" * 80)
    print(f"{'Depot ID':<10} {'Easting':<12} {'Northing':<12} {'Vehicles':<10} {'Total Time(h)':<12}")
    print("-" * 80)
    
    for _, row in depot_df.head(10).iterrows():
        print(f"{row['depot_id']:<10} {row['easting']:<12.0f} {row['northing']:<12.0f} "
              f"{row['vehicles_needed']:<10} {row['total_h_per_vehicle']:<10.2f}")
    
    # Display coordinate system information
    print("\n" + "=" * 80)
    print("Coordinate System Information")
    print("=" * 80)
    print("Coordinate System: EPSG:27700 (British National Grid)")
    print("Unit: meters")
    
    if len(depot_df) > 0:
        print(f"Easting Range: {depot_df['easting'].min():.0f} - {depot_df['easting'].max():.0f}")
        print(f"Northing Range: {depot_df['northing'].min():.0f} - {depot_df['northing'].max():.0f}")
    else:
        print("No coordinate data available")
    
    # Generate visualizations
    plot_existing_vs_optimized_comparison(best_config_data, depot_df)
    plot_road_network_with_depots(best_config_data, depot_df)

# ============================================================================
# MAIN OPTIMIZATION FUNCTION
# ============================================================================

def optimize_depots_and_vehicles():
    """
    Main optimization function to determine optimal depot locations and vehicle allocation.
    Uses K-means clustering with iterative search to find the best configuration.
    
    Returns:
        List of optimization results for each K value tested
    """
    print("=" * 80)
    print("DEPOT AND VEHICLE OPTIMIZATION FOR ROAD NETWORK MAINTENANCE")
    print("=" * 80)
    print("\nLoading road network data...")
    
    # Load and process road network
    try:
        roads = gpd.read_file(ROADS_PATH)
        roads = to_bng(roads)
        roads = roads[roads.geometry.notna() & 
                     roads.geometry.type.isin(["LineString", "MultiLineString"])]
    except Exception as e:
        print(f"ERROR: Failed to load road network - {e}")
        return None

    # Process road segments: apply length constraints and sample points
    print("Processing road segments and sampling points...")
    task_segments = []
    pts = []

    for geom in roads.geometry:
        segs = [geom] if geom.type == "LineString" else list(geom.geoms)
        for seg in segs:
            # Apply 47km length constraint
            segments = segment_long_roads(seg, MAX_TASK_LENGTH_KM)
            task_segments.extend(segments)
            
            # Sample points for clustering
            for segment in segments:
                pts.extend(sample_points(segment, SAMPLE_STEP_M))

    if not pts:
        print("ERROR: No sampled points generated. Check data or increase coverage.")
        return None

    demands = gpd.GeoDataFrame(geometry=pts, crs=roads.crs)
    X = np.array([(p.x, p.y) for p in demands.geometry], dtype=float)

    print(f"\nData Processing Complete:")
    print(f"  - Total road segments: {len(task_segments)}")
    print(f"  - Total sampled points: {len(pts):,}")
    
    # Optimization parameters
    K_range = range(50, 500, 25)
    results = []
    best_config_data = None
    
    print("\n" + "=" * 80)
    print("OPTIMIZATION SEARCH")
    print("=" * 80)
    print(f"Objective: Vehicle work time ≤ {TIME_BUDGET_H} hours (spatial split optimization)")
    print(f"Constraints:")
    print(f"  - Max vehicles per depot: {MAX_VEH_PER_DEPOT}")
    print(f"  - Work speed: {WORK_SPEED_KMH} km/h")
    print(f"  - Travel speed: {TRAVEL_SPEED_KMH} km/h")
    print(f"  - Detour factor: {DETOUR_FACTOR}")
    print(f"  - Max task length: {MAX_TASK_LENGTH_KM} km")
    print("=" * 80 + "\n")
    
    for K in K_range:
        print(f"Testing K={K} depots... ", end="")
        
        # K-means clustering
        km = KMeans(n_clusters=K, n_init=10, random_state=42)
        labels = km.fit_predict(X)
        centers = km.cluster_centers_
        
        # Calculate statistics
        stats, feasible_count, vehicles_needed = calculate_depot_stats(
            X, centers, labels, K)
        
        # Calculate average vehicle times
        vehicle_times = [s["total_h_per_vehicle"] for s in stats 
                        if s["feasible"] and s["points"] > 0]
        avg_time = np.mean(vehicle_times) if vehicle_times else 0
        max_time = np.max(vehicle_times) if vehicle_times else 0
        
        feasible_ratio = feasible_count / K
        
        result = {
            "K": K,
            "feasible_count": feasible_count,
            "feasible_ratio": feasible_ratio,
            "avg_time": avg_time,
            "max_time": max_time,
            "vehicles_needed": vehicles_needed
        }
        results.append(result)
        
        # Store current configuration
        current_config_data = {
            "K": K,
            "centers": centers.copy(),
            "labels": labels.copy(),
            "stats": stats.copy(),
            "X": X.copy()
        }
        
        # Update best configuration
        if feasible_ratio == 1.0:
            # 100% feasible configurations have priority
            if best_config_data is None or best_config_data.get("feasible_ratio", 0) < 1.0:
                best_config_data = current_config_data.copy()
                best_config_data["feasible_ratio"] = feasible_ratio
                best_config_data["vehicles_needed"] = vehicles_needed
        else:
            # Otherwise, select configuration with highest feasibility
            if best_config_data is None or feasible_ratio > best_config_data.get("feasible_ratio", 0):
                best_config_data = current_config_data.copy()
                best_config_data["feasible_ratio"] = feasible_ratio
                best_config_data["vehicles_needed"] = vehicles_needed
        
        print(f"Feasible: {feasible_count}/{K} ({feasible_ratio:.1%}), "
              f"Vehicles: {vehicles_needed}, Avg Time: {avg_time:.2f}h, Max Time: {max_time:.2f}h")
        
        # Stop if 100% feasible configuration found
        if feasible_ratio == 1.0:
            print(f"\nSUCCESS: Found 100% feasible configuration!")
            print(f"Configuration: K={K} depots, {vehicles_needed} vehicles needed")
            print("Stopping search and generating results...\n")
            break
    
    # Analyze results
    if len(results) == 0:
        print("ERROR: No valid configurations found")
        return None
        
    df_results = pd.DataFrame(results)
    
    print("\n" + "=" * 80)
    print("OPTIMIZATION RESULTS ANALYSIS")
    print("=" * 80)
    
    # Find all 100% feasible configurations
    all_feasible = df_results[df_results["feasible_ratio"] == 1.0]
    
    if len(all_feasible) > 0:
        print(f"\nFound {len(all_feasible)} configuration(s) with 100% feasibility:\n")
        for _, row in all_feasible.iterrows():
            print(f"  K={row['K']}: Avg Time={row['avg_time']:.2f}h, "
                  f"Max Time={row['max_time']:.2f}h, Total Vehicles={row['vehicles_needed']}")
        
        # Recommend optimal configuration (minimum total vehicles)
        best_config = all_feasible.loc[all_feasible["vehicles_needed"].idxmin()]
        print("\n" + "=" * 80)
        print("RECOMMENDED CONFIGURATION")
        print("=" * 80)
        print(f"Number of Depots: {best_config['K']}")
        print(f"Total Vehicles Needed: {best_config['vehicles_needed']}")
        print(f"Avg Work Time per Vehicle: {best_config['avg_time']:.2f} hours")
        print(f"Max Work Time per Vehicle: {best_config['max_time']:.2f} hours")
        print(f"Feasibility: 100%")
        
        # Save best configuration
        save_best_config_coordinates(best_config_data, best_config)
        
    else:
        print("\nWARNING: No configuration with 100% feasibility found")
        
        # Find configuration with highest feasibility
        best_feasible = df_results.loc[df_results["feasible_ratio"].idxmax()]
        print("\n" + "=" * 80)
        print("BEST AVAILABLE CONFIGURATION")
        print("=" * 80)
        print(f"Number of Depots: {best_feasible['K']}")
        print(f"Feasible Depot Ratio: {best_feasible['feasible_ratio']:.1%}")
        print(f"Total Vehicles Needed: {best_feasible['vehicles_needed']}")
        print(f"Avg Work Time per Vehicle: {best_feasible['avg_time']:.2f} hours")
        print(f"Max Work Time per Vehicle: {best_feasible['max_time']:.2f} hours")
        
        print("\nUsing best available configuration for visualization...")
        save_best_config_coordinates(best_config_data, best_feasible)
    
    # Save detailed results
    df_results.to_csv("optimization_results.csv", index=False)
    print(f"\nDetailed results saved to: optimization_results.csv")
    
    # Generate optimization analysis plots
    print("\nGenerating optimization analysis charts...")
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 2, 1)
    plt.plot(df_results["K"], df_results["feasible_ratio"], 'b-o')
    plt.xlabel("Number of Depots (K)")
    plt.ylabel("Feasible Ratio")
    plt.title("Feasibility vs Number of Depots")
    plt.grid(True, alpha=0.3)
    
    plt.subplot(2, 2, 2)
    plt.plot(df_results["K"], df_results["avg_time"], 'g-o')
    plt.xlabel("Number of Depots (K)")
    plt.ylabel("Avg Work Time per Vehicle (Hours)")
    plt.title("Average Work Time vs Number of Depots")
    plt.grid(True, alpha=0.3)
    
    plt.subplot(2, 2, 3)
    plt.plot(df_results["K"], df_results["max_time"], 'r-o')
    plt.xlabel("Number of Depots (K)")
    plt.ylabel("Max Work Time per Vehicle (Hours)")
    plt.title("Maximum Work Time vs Number of Depots")
    plt.grid(True, alpha=0.3)
    
    plt.subplot(2, 2, 4)
    plt.plot(df_results["K"], df_results["vehicles_needed"], 'm-o')
    plt.xlabel("Number of Depots (K)")
    plt.ylabel("Total Vehicles Needed")
    plt.title("Total Vehicle Demand vs Number of Depots")
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig("optimization_analysis.png", dpi=150, bbox_inches='tight')
    plt.show()
    
    print("Optimization analysis chart saved to: optimization_analysis.png")
    
    print("\n" + "=" * 80)
    print("OPTIMIZATION COMPLETE")
    print("=" * 80)
    
    return results

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    results = optimize_depots_and_vehicles()
