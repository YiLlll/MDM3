import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
import warnings

# Suppress font warnings
warnings.filterwarnings('ignore', category=UserWarning, module='matplotlib')

# Configuration
SCRIPT_DIR = Path(__file__).parent
GEOJSON_PATH = SCRIPT_DIR / "area9_combined_routes.geojson"

def plot_area9_map():
    """Plot Area 9 road network map"""
    print("Loading Area 9 route data...")
    
    try:
        # Load GeoJSON file
        gdf = gpd.read_file(GEOJSON_PATH)
        print(f"Successfully loaded {len(gdf)} features")
        
        # Set font to avoid Chinese character issues
        plt.rcParams['font.family'] = 'DejaVu Sans'
        
        # Create the plot
        fig, ax = plt.subplots(figsize=(12, 10))
        
        # Get unique routes and assign colors
        unique_routes = gdf['route_name'].unique()
        colors = plt.cm.tab20(np.linspace(0, 1, len(unique_routes)))
        
        # Plot all routes
        for i, route in enumerate(unique_routes):
            route_data = gdf[gdf['route_name'] == route]
            route_data.plot(ax=ax, color=colors[i], linewidth=1.5, alpha=0.8)
        
        # Set plot properties
        ax.set_title("Area 9 Road Network", fontsize=16, fontweight='bold')
        ax.set_xlabel("Easting (m)")
        ax.set_ylabel("Northing (m)")
        ax.grid(True, alpha=0.3)
        ax.set_aspect('equal')
        
        # Adjust layout and show
        plt.tight_layout()
        plt.show()
        
        print(f"Map plotting completed. Total routes: {len(unique_routes)}")
        
    except FileNotFoundError:
        print(f"Error: File not found - {GEOJSON_PATH}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    plot_area9_map()
